SANKHLA GROUP WEBSITE — FREE HOSTING GUIDE

Files:
- index.html: website content
- style.css: responsive design
- script.js: product catalogue, filters, Hindi toggle, WhatsApp order links

IMPORTANT:
- Demo product names/prices/artwork are temporary.
- The WhatsApp number in script.js and index.html is set to 919587934131. Check/change it before publishing.
- No actual Sankhla Group uploaded logo file was included in this package; the SG monogram is a temporary text mark.
- This is a static website and does not process payments or store orders.

PUBLISH WITH GITHUB PAGES:
1. Download and extract this ZIP.
2. Sign in to https://github.com/ or create an account.
3. Tap + > New repository.
4. Repository name: sankhlagroup.github.io (GitHub Pages user-site format requires your exact GitHub username; if username differs, use USERNAME.github.io instead).
5. Set Public and create repository.
6. Choose Add file > Upload files. Upload index.html, style.css, script.js (and README.txt if desired) from the extracted folder. Upload the files themselves, not the ZIP.
7. Commit changes.
8. Open repository Settings > Pages.
9. Under Build and deployment, choose Deploy from a branch; branch main and folder /(root), then Save.
10. Wait a few minutes. GitHub will show the live URL in Settings > Pages.
11. If you named the repo USERNAME.github.io, the URL is https://USERNAME.github.io/ . Otherwise it is https://USERNAME.github.io/REPOSITORY-NAME/ .
12. To use a custom domain later, buy a domain and configure it in Settings > Pages.

Alternative: Netlify Drop may be easier from a computer; upload the extracted site folder at https://app.netlify.com/drop. On a phone, GitHub's upload flow is often more manageable.

Before publishing:
- Confirm the phone/WhatsApp number.
- Replace demo product descriptions, prices, and artwork with actual products.
- Replace the SG text monogram with the real logo image if available.
